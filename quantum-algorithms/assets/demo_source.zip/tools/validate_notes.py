"""Independent small-state checks for the manuscript's mathematical conventions.

All basis indices are big-endian integers; gates are applied left-to-right.
This script uses NumPy independently of any later PennyLane demo.
"""
from pathlib import Path
import json
import math
import argparse
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TOL = 1e-12
checks = []

def record(name, cases, error, details):
    if error > TOL:
        raise AssertionError(f"{name}: {error} > {TOL}")
    checks.append(dict(name=name, cases=cases, max_error=float(error), tolerance=TOL, details=details))

def hmatrix(n):
    h = np.array([[1, 1], [1, -1]], dtype=complex)/np.sqrt(2)
    out = np.ones((1,1), dtype=complex)
    for _ in range(n):
        out = np.kron(out, h)
    return out

def qft(n):
    N = 1 << n
    j = np.arange(N)
    return np.exp(2j*np.pi*j[:,None]*j[None,:]/N)/np.sqrt(N)

def apply_h_rows(matrix, wire, n):
    mask = 1 << (n-1-wire)
    for i in range(1 << n):
        if not i & mask:
            a, b = matrix[i].copy(), matrix[i | mask].copy()
            matrix[i], matrix[i | mask] = (a+b)/np.sqrt(2), (a-b)/np.sqrt(2)

def swap_rows(matrix, w1, w2, n):
    m1, m2 = 1 << (n-1-w1), 1 << (n-1-w2)
    mapping = [i ^ (m1|m2) if bool(i&m1) != bool(i&m2) else i for i in range(1<<n)]
    matrix[:] = matrix[mapping]

def standard_qft(n):
    M = np.eye(1<<n,dtype=complex)
    for w in range(n):
        apply_h_rows(M,w,n)
        for control in range(w+1,n):
            angle=2*np.pi/(1 << (control-w+1))
            for i in range(1<<n):
                if (i >> (n-1-w))&1 and (i >> (n-1-control))&1:
                    M[i] *= np.exp(1j*angle)
    for w in range(n//2):
        swap_rows(M,w,n-1-w,n)
    return M

def recursive_qft(n):
    if n == 1:
        return hmatrix(1)
    N=1<<n
    M=np.kron(recursive_qft(n-1),np.eye(2))
    for i in range(N):
        y,a=divmod(i,2)
        M[i]*=np.exp(2j*np.pi*a*y/N)
    apply_h_rows(M,n-1,n)
    for w in range(n-2,-1,-1):
        swap_rows(M,w,w+1,n)
    return M

def query_checks():
    cases=0; err=0
    # Deutsch/DJ and BV: build the joint XOR oracle state explicitly.
    for n in range(1,4):
        N=1<<n; H=hmatrix(n)
        for truth in range(1<<N):
            f=np.array([(truth>>x)&1 for x in range(N)])
            if int(f.sum()) not in [0,N//2,N]:
                continue
            state=np.tile(np.array([1,-1])/np.sqrt(2*N),(N,1)).astype(complex)
            for x in range(N):
                if f[x]: state[x]=state[x,::-1]
            output=H@state; p=np.sum(np.abs(output)**2,axis=1)
            expect=float(f.sum() in [0,N])
            err=max(err,abs(p[0]-expect),abs(p.sum()-1)); cases+=1
    record("Deutsch / Deutsch-Jozsa promised functions",cases,err,"n=1..3; all promised truth tables; explicit joint XOR action")
    cases=0; err=0
    for n in range(1,6):
        N=1<<n; H=hmatrix(n)
        for s in range(N):
            f=np.array([(x&s).bit_count()%2 for x in range(N)])
            out=H@((-1.)**f/np.sqrt(N)); p=np.abs(out)**2
            expect=np.eye(N)[s]
            err=max(err,float(np.max(np.abs(p-expect)))); cases+=1
    record("Bernstein-Vazirani",cases,err,"n=1..5; every secret; big-endian output integer s")
    cases=0; err=0
    for n in range(1,5):
        N=1<<n; H=hmatrix(n)
        for s in range(N):
            state=np.zeros((N,N),complex)
            for x in range(N):
                f=x if s==0 else min(x,x^s)
                state[x,f]=1/np.sqrt(N)
            p=np.sum(np.abs(H@state)**2,axis=1)
            expect=np.full(N,1/N) if s==0 else np.array([2/N if (y&s).bit_count()%2==0 else 0 for y in range(N)])
            err=max(err,float(np.max(np.abs(p-expect))),abs(p.sum()-1)); cases+=1
    record("Simon",cases,err,"n=1..4; every period including zero; output-register marginal, not a guessed pure input state")

query_checks()
err=0
for n in range(1,6):
    F=qft(n)
    err=max(err,np.max(np.abs(standard_qft(n)-F)),np.max(np.abs(recursive_qft(n)-F)))
record("QFT gate order / permutations",10,err,"m=1..5; standard H/CP/reversal and manuscript-derived recursion vs independent Fourier matrix")

err=0; cases=0; min_nearest=1
for m in range(2,9):
    N=1<<m; F=qft(m)
    for theta in [0.,.125,.5,.999,1/3,np.sqrt(2)%1]:
        wave=np.exp(2j*np.pi*np.arange(N)*theta)/np.sqrt(N)
        p=np.abs(F.conj().T@wave)**2
        nearest=round(N*theta)%N
        min_nearest=min(min_nearest,p[nearest])
        expect=[]
        for y in range(N):
            delta=theta-y/N
            amp=np.mean(np.exp(2j*np.pi*np.arange(N)*delta))
            expect.append(abs(amp)**2)
        err=max(err,abs(p.sum()-1),np.max(np.abs(p-expect)));cases+=1
assert min_nearest >= 4/np.pi**2 - TOL
record("QPE distribution",cases,err,f"m=2..8; exact and nonexact phases, wrap-around; minimum nearest-cell probability {min_nearest:.12f}")

err=0; cases=0
for N,a in [(7,3),(15,2)]:
    d=1 << math.ceil(math.log2(N)); U=np.zeros((d,d),complex)
    for x in range(d): U[(a*x)%N if x<N else x,x]=1
    orbit=[1]; x=a%N
    while x!=1: orbit.append(x);x=(a*x)%N
    r=len(orbit); eigen=[]
    for j in range(r):
        psi=np.zeros(d,complex)
        for k,x in enumerate(orbit):psi[x]=np.exp(-2j*np.pi*j*k/r)/np.sqrt(r)
        err=max(err,np.max(np.abs(U@psi-np.exp(2j*np.pi*j/r)*psi)));eigen.append(psi);cases+=1
    one=np.zeros(d);one[1]=1
    err=max(err,np.max(np.abs(sum(eigen)/np.sqrt(r)-one)),np.max(np.abs(U.conj().T@U-np.eye(d))))
record("Modular multiplication eigenstates",cases,err,"(N,a)=(7,3),(15,2); unitary extension fixes x>=N; negative eigenstate phase and positive eigenvalue")

err=0; cases=0
for n in range(1,8):
    N=1<<n; u=np.ones(N)/np.sqrt(N)
    for s in range(1,N):
        theta=np.arcsin(np.sqrt(s/N)); state=u.copy()
        for t in range(min(12,math.floor(np.pi/(4*theta))+3)):
            expect=np.sin((2*t+1)*theta)**2
            err=max(err,abs(np.sum(state[:s]**2)-expect),abs(state@state-1));cases+=1
            state[:s]*=-1
            state=2*state.mean()-state
        tstar=math.floor(np.pi/(4*theta)) if s<=N/2 else 0
        p=np.sin((2*tstar+1)*theta)**2
        assert p >= max(1-s/N,s/N)-TOL
record("Grover amplitudes / integer iteration policy",cases,err,"n=1..7; all nontrivial solution counts; vector reflections compared to analytic rotation")

cases=0
for a in range(2):
    for b in range(2):
        for c in range(2):
            assert c^((a^1)&(b^1))^1 == c^(a|b)
            s=a^b^c; carry=(a&b)|((a^b)&c)
            assert a+b+c == s+2*carry
            cases+=1
record("OR and full-adder truth tables",cases,0,"all binary inputs; general target c in OR embedding")

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,default=ROOT/'build'/'validation.json')
args=parser.parse_args()
out=args.output
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({"kind":"independent NumPy checks","tolerance":TOL,"checks":checks},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({"checks":len(checks),"cases":sum(x['cases'] for x in checks),"max_error":max(x['max_error'] for x in checks),"result":str(out)},ensure_ascii=True))
