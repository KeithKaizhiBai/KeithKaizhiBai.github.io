"""Package actual retained results for a buildless, offline-capable website."""
from pathlib import Path
import argparse
import json
import shutil
import zipfile
import hashlib
import os
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parent.parent/'build'/'matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--run-id',default='local-demo-001');p.add_argument('--note-version',choices=['0.1','0.2'],default='0.1');args=p.parse_args()
    if not args.run_id.replace('-','').replace('_','').isalnum():raise ValueError('Invalid run id')
    batch=ROOT/'results'/args.run_id
    data=json.loads((batch/'results.json').read_text(encoding='utf-8'))
    dist=ROOT/'site'/'dist';assets=dist/'assets';target=dist/'data'
    for path in [assets,target]:path.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(batch/'results.json',target/'results.json')
    (target/'results.js').write_text('window.DEMO_RESULTS = '+json.dumps(data,ensure_ascii=False,allow_nan=False)+';\n',encoding='utf-8')
    original_note=PROJECT/'output'/'pdf'/'quantum_algorithms_v0.1.pdf'
    if hashlib.sha256(original_note.read_bytes()).hexdigest()!=data['note']['pdf_sha256']:
        raise ValueError('Current note differs from the note used by this run')
    note=PROJECT/'output'/'pdf'/f'quantum_algorithms_v{args.note_version}.pdf'
    manifest=json.loads((PROJECT/'output'/'pdf'/('manifest_v0.2.json' if args.note_version=='0.2' else 'manifest.json')).read_text(encoding='utf-8'))
    if hashlib.sha256(note.read_bytes()).hexdigest()!=manifest['pdf_sha256']:raise ValueError('Display note manifest does not match its PDF')
    shutil.copyfile(note,assets/note.name)
    shutil.copyfile(note.with_suffix('.tex'),assets/note.with_suffix('.tex').name)
    sources={}
    for relative,expected_hash in data['source_sha256'].items():
        file=batch/'source'/Path(relative).relative_to('demo')
        contents=file.read_bytes()
        if hashlib.sha256(contents).hexdigest()!=expected_hash:raise ValueError(f'Source snapshot mismatch: {relative}')
        if (PROJECT/relative).read_bytes()!=contents:raise ValueError(f'Active calculation differs from frozen snapshot: {relative}')
        sources[relative.replace('\\','/')]=contents.decode('utf-8')
    for relative in ['demo/requirements.txt','demo/README.md','demo/benchmark.py','demo/build_site.py','tools/validate_notes.py']:
        sources[relative]=(PROJECT/relative).read_text(encoding='utf-8')
    (target/'sources.js').write_text('window.DEMO_SOURCES = '+json.dumps(sources,ensure_ascii=True)+';\n',encoding='utf-8')
    figures=batch/'figures';figures.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
    fig,axs=plt.subplots(4,2,figsize=(11,11),layout='constrained')
    for ax,item in zip(axs.ravel(),data['algorithms']):
        values=np.array(item['probabilities']);theory=np.array(item['expected_probabilities'])
        indices=np.argsort(values)[-min(12,len(values)):];indices=np.sort(indices)
        labels=[item['labels'][i] for i in indices];counts=np.array([item['counts'].get(x,0)/item['shots'] for x in labels])
        x=np.arange(len(indices));ax.bar(x-.17,values[indices],.34,label='Exact simulator',color='#2c7375')
        ax.bar(x+.17,counts,.34,label='Sample frequency',color='#cc6a46')
        ax.plot(x,theory[indices],'_',color='#182f33',markersize=6,label='Independent theory')
        ax.set_xticks(x,labels,rotation=45,ha='right',fontsize=7);ax.set_ylim(0,max(0.05,max(values[indices])*1.18));ax.set_ylabel('Probability')
        ax.set_title(f"{item['id'].upper()} | {item['qubits']} wires | {item['shots']} shots",loc='left',fontsize=10)
    axs[0,0].legend(frameon=False,fontsize=7)
    fig.suptitle(f"Quantum algorithms: local PennyLane run {args.run_id}\nTop 12 states per panel; ideal CPU simulation",fontsize=13)
    for ext in ['svg','png']:fig.savefig(figures/f'probability_overview.{ext}',dpi=180)
    plt.close(fig)
    grover=next(x for x in data['algorithms'] if x['id']=='grover')
    fig,ax=plt.subplots(figsize=(8,4.4),layout='constrained')
    for name,curve,color in [('1 marked state',grover['details']['curve'],'#2c7375'),('4 marked states',grover['details']['multiple_case']['curve'],'#bc4926')]:
        ax.plot([x['iterations'] for x in curve],[x['success_probability'] for x in curve],'o-',label=name,color=color,markersize=4)
    ax.set(xlabel='Grover iterations t',ylabel='Success probability',ylim=(0,1.03),title='N=128: success oscillates; more iterations can overshoot')
    ax.legend(frameon=False);ax.grid(alpha=.18)
    for ext in ['svg','png']:fig.savefig(figures/f'grover_iterations.{ext}',dpi=180)
    plt.close(fig)
    for source in figures.iterdir():shutil.copyfile(source,assets/source.name)
    with zipfile.ZipFile(assets/'demo_source.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        normalized_hashes={name.replace('\\','/'):value for name,value in data['source_sha256'].items()}
        for pattern in ['*.py','*.ps1','requirements.txt','README.md','hardware.json','benchmark.json','algorithms/*.py']:
            for file in ROOT.glob(pattern):
                relative=file.relative_to(PROJECT).as_posix()
                if relative in normalized_hashes:
                    archive.write(batch/'source'/Path(relative).relative_to('demo'),relative)
                else:archive.write(file,relative)
        for filename in ['manifest.json','quantum_algorithms_v0.1.pdf','quantum_algorithms_v0.1.tex']:
            archive.write(PROJECT/'output/pdf'/filename,'output/pdf/'+filename)
        if args.note_version=='0.2':
            for filename in ['manifest_v0.2.json','quantum_algorithms_v0.2.pdf','quantum_algorithms_v0.2.tex']:
                archive.write(PROJECT/'output/pdf'/filename,'output/pdf/'+filename)
        archive.write(PROJECT/'tools/validate_notes.py','tools/validate_notes.py')
        for filename in ['index.html','style.css','app.js','icon.svg']:
            archive.write(dist/filename,'demo/site/dist/'+filename)
    (dist/'site_manifest.json').write_text(json.dumps({'run_id':args.run_id,'results_sha256':hashlib.sha256((batch/'results.json').read_bytes()).hexdigest(),
                    'note_sha256':manifest['pdf_sha256'],'display_note_version':args.note_version,'display_note_pages':manifest['pages'],
                    'original_run_note_sha256':data['note']['pdf_sha256'],
                    'source_sha256':data['source_sha256'],
                    'data_kind':'executed local PennyLane results; no live browser simulation'},indent=2),encoding='utf-8')
    print(f'Packaged local website: {dist}')

if __name__=='__main__':main()
