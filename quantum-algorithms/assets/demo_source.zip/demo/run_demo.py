"""Execute the bounded teaching suite and retain an immutable results batch.

Run with the project virtual environment. No network access occurs during runs.
Outputs use big-endian bit strings, matching the LaTeX note.
"""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(name,'4')
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse
import hashlib
import importlib.metadata as metadata
import json
import platform
import time
import pennylane as qml
import numpy as np
from algorithms import query,phase,search

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent

def main():
    parser=argparse.ArgumentParser(description='Small local PennyLane learning demonstrations')
    parser.add_argument('--run-id',default='local-demo-001')
    parser.add_argument('--shots',type=int,default=2048)
    parser.add_argument('--seed',type=int,default=20261012)
    args=parser.parse_args()
    if not args.run_id.replace('-','').replace('_','').isalnum():raise ValueError('Invalid run id')
    if not 128<=args.shots<=8192:raise ValueError('shots must be 128..8192 for this bounded demo')
    destination=ROOT/'results'/args.run_id
    if destination.exists():raise FileExistsError(f'Results batch already exists: {destination}; choose a new --run-id')
    source_paths=[Path(__file__).resolve(),ROOT/'algorithms'/'query.py',ROOT/'algorithms'/'phase.py',ROOT/'algorithms'/'search.py']
    source_bytes={str(p.relative_to(PROJECT)):p.read_bytes() for p in source_paths}
    source={name:hashlib.sha256(contents).hexdigest() for name,contents in source_bytes.items()}
    start=time.perf_counter();results=[]
    for module in [query,phase,search]:
        print(f'Running {module.__name__}',flush=True)
        items=module.run(seed=args.seed,shots=args.shots)
        for item in items:
            if not item['validation_passed']:raise AssertionError(f"{item['id']} validation failed")
            if abs(sum(item['probabilities'])-1)>1e-10:raise AssertionError('Probabilities do not normalize')
            if sum(item['counts'].values())!=item['shots']:raise AssertionError('Sample count mismatch')
            print(f"  {item['id']}: {item['qubits']} wires, error={item['max_error']:.3g}",flush=True)
        results.extend(items)
    ids=[x['id'] for x in results]
    if sorted(ids)!=sorted(['deutsch','dj','bv','simon','qft','qpe','order','grover']):raise AssertionError(f'Unexpected algorithm set {ids}')
    note_manifest=json.loads((PROJECT/'output'/'pdf'/'manifest.json').read_text(encoding='utf-8'))
    for name,contents in source_bytes.items():
        if (PROJECT/name).read_bytes()!=contents:raise RuntimeError(f'Computation source changed during execution: {name}')
    record={'schema_version':1,'run_id':args.run_id,
            'executed_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
            'backend':'PennyLane default.qubit · ideal CPU simulator',
            'shots':args.shots,'seed':args.seed,'total_elapsed_seconds':time.perf_counter()-start,
            'environment':{'python':platform.python_version(),'pennylane':qml.__version__,'numpy':np.__version__,
                           'os':platform.system(),'threads':4},
            'hardware':json.loads((ROOT/'hardware.json').read_text(encoding='utf-8-sig')),
            'benchmark':json.loads((ROOT/'benchmark.json').read_text(encoding='utf-8')),
            'note':note_manifest,'source_sha256':source,'algorithms':results,
            'limitations':['Ideal classical state-vector simulation, not quantum hardware.',
                           'Dense teaching operators for small order-finding examples do not demonstrate scalable modular arithmetic.',
                           'Finite-shot counts are recorded separately from exact simulator probabilities; identical seeds do not prove cross-version determinism.']}
    destination.mkdir(parents=True)
    for name,contents in source_bytes.items():
        snapshot=destination/'source'/Path(name).relative_to('demo')
        snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(contents)
    (destination/'results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    with (destination/'probabilities.csv').open('w',encoding='utf-8',newline='') as stream:
        import csv
        writer=csv.writer(stream);writer.writerow(['algorithm','basis','exact_probability','theory_probability','sample_count','shots'])
        for item in results:
            for label,p,e in zip(item['labels'],item['probabilities'],item['expected_probabilities']):
                writer.writerow([item['id'],label,p,e,item['counts'].get(label,0),item['shots']])
    print(f'Retained results batch: {destination}',flush=True)

if __name__=='__main__':main()
