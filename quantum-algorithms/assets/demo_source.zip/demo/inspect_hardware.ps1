$ErrorActionPreference = 'Stop'
$demoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$cpuInfo = Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed
$osInfo = Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,TotalVisibleMemorySize,FreePhysicalMemory
$gpuInfo = Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion
$gpuMemory = $null
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
    $gpuMemory = nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader
    if ($LASTEXITCODE -ne 0) { throw 'GPU memory query failed' }
}
$record = [ordered]@{
    captured_at = [DateTimeOffset]::UtcNow.ToOffset([TimeSpan]::FromHours(8)).ToString('o')
    cpu = $cpuInfo
    os = $osInfo
    gpu = $gpuInfo
    gpu_memory_query = $gpuMemory
    backend_decision = 'CPU default.qubit; GPU detected but not used or benchmarked'
    scope = 'CPU, RAM, GPU model and driver only; no host/user identifiers or credentials'
}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $demoRoot 'hardware.json') -Encoding utf8
