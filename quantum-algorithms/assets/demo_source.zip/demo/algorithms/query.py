"""Query algorithms from note sections 1.2--1.5, run on PennyLane CPU.

Wire 0 is the most significant input bit. Input wires precede work wires.
Analytic probabilities and genuine finite-shot samples are separate runs;
the 1e-10 validation threshold applies to analytic probabilities, not to
the statistical difference between sample frequencies and probabilities.
No circuit here prepares a known answer as its output state.
"""

from collections import Counter
from collections.abc import Callable
from time import perf_counter

import numpy as np
import pennylane as qml


PROBABILITY_TOLERANCE = 1e-10


def _bits(value: int, width: int) -> list[int]:
    """Return most-significant-bit-first binary digits, length ``width``."""
    return [int(bit) for bit in format(value, f"0{width}b")]


def _labels(n: int) -> list[str]:
    return [format(value, f"0{n}b") for value in range(1 << n)]


def _point_distribution(value: int, n: int) -> list[float]:
    return [float(index == value) for index in range(1 << n)]


def _evaluate(
    body: Callable[[], None],
    n: int,
    qubits: int,
    expected: list[float],
    seed: int,
    shots: int,
) -> tuple[dict, np.ndarray]:
    """Execute a unitary body, measuring its first n wires in big-endian order.

    Returns a JSON-safe analytic/sample record and raw samples of shape
    (shots, n). Every count comes from qml.sample, never synthetic sampling.
    """
    started = perf_counter()
    analytic_device = qml.device("default.qubit", wires=qubits, seed=seed)
    sampling_device = qml.device("default.qubit", wires=qubits, seed=seed)

    @qml.qnode(analytic_device, interface=None, diff_method=None)
    def analytic():
        body()
        return qml.probs(wires=list(range(n)))

    @qml.qnode(sampling_device, interface=None, diff_method=None)
    def sampling():
        body()
        return qml.sample(wires=list(range(n)))

    probabilities = np.asarray(analytic(), dtype=float)
    samples = np.asarray(qml.set_shots(sampling, shots=shots)(), dtype=int)
    if samples.shape != (shots, n):
        raise RuntimeError(f"Unexpected sample shape {samples.shape}; wanted {(shots, n)}")
    labels = _labels(n)
    counts = dict(sorted(Counter("".join(map(str, row)) for row in samples).items()))
    theory = np.asarray(expected, dtype=float)
    if theory.shape != probabilities.shape:
        raise ValueError("Expected probabilities and measured register have different sizes")
    max_error = float(np.max(np.abs(probabilities - theory)))
    normalized = bool(abs(float(probabilities.sum()) - 1.0) <= PROBABILITY_TOLERANCE)
    support_valid = all(probabilities[int(label, 2)] > PROBABILITY_TOLERANCE for label in counts)
    passed = normalized and max_error <= PROBABILITY_TOLERANCE and support_valid
    if not passed:
        raise AssertionError(
            f"Quantum probability validation failed: error={max_error}, "
            f"normalized={normalized}, sample_support={support_valid}"
        )
    frequencies = np.array([counts.get(label, 0) / shots for label in labels])
    record = {
        "qubits": qubits,
        "elapsed_seconds": float(perf_counter() - started),
        "labels": labels,
        "probabilities": probabilities.tolist(),
        "expected_probabilities": theory.tolist(),
        "counts": counts,
        "shots": shots,
        "seed": seed,
        "max_error": max_error,
        "validation_passed": bool(passed),
        "circuit_text": qml.draw(analytic, decimals=2)(),
        "details": {
            "device": "default.qubit",
            "execution": "CPU statevector simulation",
            "wire_order": "输入最高有效位在wire 0；工作寄存器随后",
            "probability_tolerance": PROBABILITY_TOLERANCE,
            "sample_support_valid": bool(support_valid),
            "empirical_max_error": float(np.max(np.abs(frequencies - theory))),
            "validation_scope": "解析概率与独立理论比较；有限shots的频率偏差另行记录",
        },
    }
    return record, samples


def _make_result(
    record: dict,
    algorithm_id: str,
    title: str,
    note_ref: str,
    source_pages: str,
    summary: str,
    parameters: dict,
    circuit_steps: list[str],
) -> dict:
    return {
        "id": algorithm_id,
        "title": title,
        "note_ref": note_ref,
        "source_pages": source_pages,
        "summary": summary,
        "parameters": parameters,
        **record,
        "details": dict(record["details"]),
        "circuit_steps": circuit_steps,
    }


def _deutsch_body(values: tuple[int, int]) -> Callable[[], None]:
    def body():
        qml.PauliX(wires=1)
        qml.Hadamard(wires=0)
        qml.Hadamard(wires=1)
        # f(x) = f(0) XOR ((f(0) XOR f(1)) AND x).
        if values[0]:
            qml.PauliX(wires=1)
        if values[0] ^ values[1]:
            qml.CNOT(wires=[0, 1])
        qml.Hadamard(wires=0)

    return body


def _linear_phase_body(secret: str, offset: int = 0) -> Callable[[], None]:
    """Deutsch--Jozsa/BV with XOR oracle f(x)=secret dot x XOR offset."""
    n = len(secret)

    def body():
        qml.PauliX(wires=n)
        for wire in range(n + 1):
            qml.Hadamard(wires=wire)
        if offset:
            qml.PauliX(wires=n)
        for wire, coefficient in enumerate(secret):
            if coefficient == "1":
                qml.CNOT(wires=[wire, n])
        for wire in range(n):
            qml.Hadamard(wires=wire)

    return body


def _dj_theory(secret: str, offset: int) -> list[float]:
    """Compute the note's Fourier character sum from a classical truth table.

    This deliberately does not use a QNode or its final statevector.
    """
    n = len(secret)
    N = 1 << n
    mask = int(secret, 2)
    values = [((mask & x).bit_count() % 2) ^ offset for x in range(N)]
    return [
        (sum((-1) ** (values[x] + (x & z).bit_count()) for x in range(N)) / N) ** 2
        for z in range(N)
    ]


def _simon_matrix(secret: str) -> list[list[int]]:
    """Construct A over GF(2), with kernel span{secret}, or identity for zero.

    For the first nonzero bit p, f_p(x)=0 and f_j(x)=x_j XOR s_j*x_p
    for j != p. Then A has rank n-1 and exactly the promised pair collisions.
    Its XOR oracle is a reversible CNOT network on n input + n output wires.
    """
    n = len(secret)
    matrix = [[int(row == col) for col in range(n)] for row in range(n)]
    if "1" not in secret:
        return matrix
    pivot = secret.index("1")
    matrix[pivot] = [0] * n
    for row, bit in enumerate(secret):
        if row != pivot:
            matrix[row][pivot] = int(bit)
    return matrix


def _simon_body(matrix: list[list[int]]) -> Callable[[], None]:
    n = len(matrix)

    def body():
        for wire in range(n):
            qml.Hadamard(wires=wire)
        for output, row in enumerate(matrix):
            for input_wire, coefficient in enumerate(row):
                if coefficient:
                    qml.CNOT(wires=[input_wire, n + output])
        for wire in range(n):
            qml.Hadamard(wires=wire)

    return body


def _classical_linear_value(matrix: list[list[int]], x: str) -> str:
    bits = [int(bit) for bit in x]
    return "".join(str(sum(a * b for a, b in zip(row, bits)) % 2) for row in matrix)


def _gf2_nullspace(rows: list[list[int]], n: int) -> tuple[int, list[list[int]]]:
    """RREF and a kernel basis over GF(2); never use floating-point SVD."""
    matrix = [row.copy() for row in rows]
    pivot_columns = []
    for column in range(n):
        pivot = next(
            (row for row in range(len(pivot_columns), len(matrix)) if matrix[row][column]),
            None,
        )
        if pivot is None:
            continue
        pivot_row = len(pivot_columns)
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        for row in range(len(matrix)):
            if row != pivot_row and matrix[row][column]:
                matrix[row] = [a ^ b for a, b in zip(matrix[row], matrix[pivot_row])]
        pivot_columns.append(column)
    basis = []
    for free_column in range(n):
        if free_column in pivot_columns:
            continue
        vector = [0] * n
        vector[free_column] = 1
        for row, pivot_column in enumerate(pivot_columns):
            vector[pivot_column] = matrix[row][free_column]
        basis.append(vector)
    return len(pivot_columns), basis


def _recover_simon(samples: np.ndarray, matrix: list[list[int]]) -> dict:
    """Recover from actual samples and oracle comparison, without the secret.

    Rank n-1 leaves one nonzero candidate t. f(0)=f(t) verifies a nonzero
    period. If unequal, the promise and the unique candidate imply s=0.
    Thus the injective case may also stop at rank n-1 after two value queries.
    """
    n = samples.shape[1]
    rows: list[list[int]] = []
    rank = 0
    basis: list[list[int]] = []
    for sample in samples:
        rows.append(sample.tolist())
        rank, basis = _gf2_nullspace(rows, n)
        if rank == n:
            return {
                "rows": rows,
                "rank": rank,
                "kernel_basis": [],
                "recovered_s": "0" * n,
                "verification": {"method": "满秩核仅含零向量", "additional_value_queries": 0},
            }
        if rank == n - 1:
            candidate = "".join(map(str, basis[0]))
            f_zero = _classical_linear_value(matrix, "0" * n)
            f_candidate = _classical_linear_value(matrix, candidate)
            accepted = f_zero == f_candidate
            return {
                "rows": rows,
                "rank": rank,
                "kernel_basis": [candidate],
                "recovered_s": candidate if accepted else "0" * n,
                "verification": {
                    "method": "在唯一非零核候选上比较f(0)与f(t)，依Simon承诺判定",
                    "candidate": candidate,
                    "f_zero": f_zero,
                    "f_candidate": f_candidate,
                    "candidate_accepted": accepted,
                    "additional_value_queries": 2,
                },
            }
    return {
        "rows": rows,
        "rank": rank,
        "kernel_basis": ["".join(map(str, vector)) for vector in basis],
        "recovered_s": None,
        "verification": {"method": "真实样本秩不足，未恢复", "additional_value_queries": 0},
    }


def _run_deutsch(seed: int, shots: int) -> dict:
    cases = []
    primary = None
    total_seconds = 0.0
    for values in ((0, 0), (0, 1), (1, 0), (1, 1)):
        parity = values[0] ^ values[1]
        record, _ = _evaluate(_deutsch_body(values), 1, 2, _point_distribution(parity, 1), seed, shots)
        total_seconds += record["elapsed_seconds"]
        case = {"case": "".join(map(str, values)), "function_values": list(values), "type": "平衡" if parity else "常数", **record}
        cases.append(case)
        if values == (0, 1):
            primary = record
    result = _make_result(
        primary, "deutsch", "Deutsch：一次查询判定两点奇偶", "1.2", "6–9",
        "实际执行全部4种一比特函数；主图为f(x)=x，最终输出1判定平衡。解析结果精确，counts来自有限shots测量。",
        {"n": 1, "function_values": [0, 1], "oracle_queries_per_shot": 1, "cases_executed": 4},
        ["辅助位由X、H准备为|−⟩", "输入位施加H", "以X/CNOT实现一次异或查询", "输入位再次H并测量"],
    )
    result["elapsed_seconds"] = total_seconds
    result["details"]["cases"] = cases
    return result


def _run_dj(seed: int, shots: int) -> dict:
    n = 4
    cases = []
    primary = None
    total_seconds = 0.0
    for case_name, secret, offset in (("constant_one", "0000", 1), ("balanced_affine", "1011", 1)):
        record, _ = _evaluate(_linear_phase_body(secret, offset), n, n + 1, _dj_theory(secret, offset), seed, shots)
        total_seconds += record["elapsed_seconds"]
        cases.append({"case": case_name, "linear_coefficient": secret, "offset": offset, **record})
        if case_name == "balanced_affine":
            primary = record
    result = _make_result(
        primary, "dj", "Deutsch–Jozsa：常数与平衡函数", "1.3", "9–11",
        "n=4，运行常1函数与平衡仿射函数1011·x⊕1。主例输出1011，因此不是全零；常数对照必得0000。",
        {"n": n, "linear_coefficient": "1011", "offset": 1, "oracle_definition": "f(x)=1011·x XOR 1", "oracle_queries_per_shot": 1, "cases_executed": 2},
        ["4个输入位施加H，辅助位准备|−⟩", "X与3个CNOT实现仿射函数查询", "输入寄存器再次施加H", "测量并检查是否全零"],
    )
    result["elapsed_seconds"] = total_seconds
    result["details"]["cases"] = cases
    return result


def _run_bv(seed: int, shots: int) -> dict:
    secret = "101101"
    n = len(secret)
    record, _ = _evaluate(_linear_phase_body(secret), n, n + 1, _point_distribution(int(secret, 2), n), seed, shots)
    result = _make_result(
        record, "bv", "Bernstein–Vazirani：恢复隐藏线性串", "1.4", "12–13",
        "n=6，隐藏串101101。由CNOT网络计算线性函数，测量必得101101；每次电路调用一次oracle。",
        {"n": n, "secret": secret, "oracle_definition": "f(x)=101101·x", "oracle_queries_per_shot": 1},
        ["6位均匀叠加，辅助位准备|−⟩", "在隐藏串为1的4个位上使用CNOT", "最后H层让字符干涉集中到隐藏串", "测量输入6位"],
    )
    result["details"]["recovered_s"] = result["labels"][int(np.argmax(result["probabilities"]))]
    return result


def _run_simon(seed: int, shots: int) -> dict:
    n = 4
    cases = []
    primary = None
    total_seconds = 0.0
    for secret in ("1011", "0000"):
        matrix = _simon_matrix(secret)
        mask = int(secret, 2)
        # Independent formula: all y for injective f; otherwise y dot s = 0.
        expected = [
            1 / (1 << n) if mask == 0 else (2 / (1 << n) if (mask & y).bit_count() % 2 == 0 else 0.0)
            for y in range(1 << n)
        ]
        record, samples = _evaluate(_simon_body(matrix), n, 2 * n, expected, seed, shots)
        recovery_started = perf_counter()
        recovery = _recover_simon(samples, matrix)
        record["elapsed_seconds"] += float(perf_counter() - recovery_started)
        total_seconds += record["elapsed_seconds"]
        recovery_ok = recovery["recovered_s"] == secret
        if not recovery_ok:
            raise AssertionError(f"Simon sample recovery failed for {secret}: {recovery}")
        # Exhaustive classical promise check, separate from probability prediction.
        truth_table = {x: _classical_linear_value(matrix, x) for x in _labels(n)}
        promise_valid = all(
            (truth_table[x] == truth_table[z]) == (x == z or (int(x, 2) ^ int(z, 2)) == mask)
            for x in truth_table for z in truth_table
        )
        if not promise_valid:
            raise AssertionError("Constructed Simon oracle violates its classical promise")
        record["details"].update({
            "oracle_matrix_gf2": matrix,
            "oracle_truth_table": truth_table,
            "promise_validated": promise_valid,
            "sample_rows": samples[: min(shots, 16)].tolist(),
            "sample_rows_shown": min(shots, 16),
            "sample_rows_total": shots,
            "recovery_rows": recovery["rows"],
            "recovery_samples_used": len(recovery["rows"]),
            "rank": recovery["rank"],
            "kernel_basis": recovery["kernel_basis"],
            "recovered_s": recovery["recovered_s"],
            "candidate_verification": recovery["verification"],
            "recovery_validated": bool(recovery_ok),
            "orthogonality_violations": int(sum((int("".join(map(str, row)), 2) & mask).bit_count() % 2 for row in samples)),
        })
        case = {"case": "two_to_one" if mask else "injective", "secret": secret, **record}
        cases.append(case)
        if mask:
            primary = record
    result = _make_result(
        primary, "simon", "Simon：采样正交约束并解线性方程", "1.5", "13–17",
        "8量子比特实现4输入+4输出。主例由真实采样恢复1011，所有样本满足y·1011=0；另运行一一函数对照。",
        {"n": n, "m": n, "secret": "1011", "oracle_definition": "f(x)=Ax over GF(2), rank(A)=3, kernel(A)=span{1011}", "oracle_queries_per_shot": 1, "cases_executed": 2},
        ["4输入位H，4输出位保持|0000⟩", "用CNOT网络执行|x⟩|z⟩→|x⟩|z⊕Ax⟩", "输入位H后实际采样", "GF(2)消元并通过f(0)=f(t)验证唯一非零核候选"],
    )
    result["elapsed_seconds"] = total_seconds
    # Copy before assigning cases: avoid recursive dictionaries in JSON output.
    result["details"] = {**primary["details"], "cases": cases}
    return result


def run(seed: int = 20261012, shots: int = 2048) -> list[dict]:
    """Run four query-algorithm demonstrations with a bounded local budget.

    The nine case circuits use at most eight simulated qubits. ``shots`` is
    the finite sample count per case, not an analytic precision parameter.
    A recovery failure is raised explicitly rather than hidden by fake counts.
    """
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    if not isinstance(shots, int) or isinstance(shots, bool) or shots < 16:
        raise ValueError("shots must be an integer >= 16 for the Simon recovery demonstration")
    return [_run_deutsch(seed, shots), _run_dj(seed, shots), _run_bv(seed, shots), _run_simon(seed, shots)]
