"""Seven-qubit Grover demonstrations with gate oracles and actual CPU sampling.

Wire 0 is the most significant bit. Probabilities are in integer order 0..127.
The diffusion gate sequence implements -D; hence every iteration is -C rather
than C. Its global sign cancels from these uncontrolled measurement experiments.
This implementation is not intended for controlled Grover or phase estimation.
"""

from collections import Counter
import math
import time

import numpy as np
import pennylane as qml


N_QUBITS = 7
N_STATES = 1 << N_QUBITS
UNIQUE_MARKED = (73,)
MULTIPLE_MARKED = (5, 37, 73, 109)
TOLERANCE = 1e-10
MAX_UNKNOWN_TRIALS = 32


def _bits(value: int) -> str:
    """Return seven big-endian bits, in the same order as wires 0..6."""
    return format(value, f"0{N_QUBITS}b")


def _all_one_phase(wires: tuple[int, ...]) -> None:
    """Flip only the all-one basis amplitude: H(target), MCX, H(target)."""
    qml.Hadamard(wires=wires[-1])
    qml.MultiControlledX(wires=wires)
    qml.Hadamard(wires=wires[-1])


def _phase_oracle(marked: tuple[int, ...], wires: tuple[int, ...]) -> None:
    """Implement (-1)^f(x), with one phase flip for each distinct marked x.

    An X on each zero bit maps the marked bit string to all ones. The final X
    gates restore every bit. No diagonal matrix or hand-generated state is used.
    """
    for value in marked:
        zero_wires = tuple(w for w, bit in zip(wires, _bits(value)) if bit == "0")
        for wire in zero_wires:
            qml.PauliX(wires=wire)
        _all_one_phase(wires)
        for wire in zero_wires:
            qml.PauliX(wires=wire)


def _diffusion(wires: tuple[int, ...]) -> None:
    """Apply -D = H^n X^n (multi-controlled Z) X^n H^n, with no work bits."""
    for wire in wires:
        qml.Hadamard(wires=wire)
    for wire in wires:
        qml.PauliX(wires=wire)
    _all_one_phase(wires)
    for wire in wires:
        qml.PauliX(wires=wire)
    for wire in wires:
        qml.Hadamard(wires=wire)


def _make_nodes(marked: tuple[int, ...], seed: int):
    """Create analytic and sampling QNodes; both prepare and run actual gates."""
    wires = tuple(range(N_QUBITS))
    analytic_device = qml.device("default.qubit", wires=wires)
    sample_device = qml.device("default.qubit", wires=wires, seed=seed)

    def operations(iterations: int) -> None:
        for wire in wires:
            qml.Hadamard(wires=wire)
        for _ in range(iterations):
            _phase_oracle(marked, wires)
            _diffusion(wires)

    @qml.qnode(analytic_device)
    def probabilities(iterations: int):
        operations(iterations)
        return qml.probs(wires=wires)

    @qml.qnode(sample_device)
    def samples(iterations: int):
        operations(iterations)
        return qml.sample(wires=wires)

    return probabilities, samples


def _theory(marked: tuple[int, ...], iterations: int) -> tuple[np.ndarray, float]:
    """Independent rotation prediction; a 128-vector and total success rate.

    Each marked state has probability sin²((2t+1)θ)/s. All other states have
    probability cos²((2t+1)θ)/(128-s), with θ=arcsin(sqrt(s/128)).
    """
    s = len(marked)
    theta = math.asin(math.sqrt(s / N_STATES))
    success = math.sin((2 * iterations + 1) * theta) ** 2
    expected = np.full(N_STATES, (1 - success) / (N_STATES - s), dtype=float)
    expected[list(marked)] = success / s
    return expected, success


def _sample_counts(node, iterations: int, shots: int) -> dict[str, int]:
    """Count actual qml.sample basis draws, never synthetic probability counts."""
    raw = np.asarray(qml.set_shots(node, shots=shots)(iterations), dtype=int)
    if raw.shape != (shots, N_QUBITS):
        raise ValueError(f"Unexpected sample shape {raw.shape}; wanted {(shots, N_QUBITS)}")
    if np.any((raw != 0) & (raw != 1)):
        raise ValueError("Nonbinary basis measurement returned by device")
    counts = Counter("".join(str(int(bit)) for bit in row) for row in raw)
    return dict(sorted(counts.items()))


def _known_case(marked: tuple[int, ...], seed: int, shots: int) -> dict:
    """Execute 17 analytic QNode calls, then sample the selected stopping point."""
    theta = math.asin(math.sqrt(len(marked) / N_STATES))
    optimal = math.floor(math.pi / (4 * theta))
    probability_node, sample_node = _make_nodes(marked, seed)
    curve = []
    maximum_error = 0.0
    selected = None
    selected_expected = None
    for iterations in range(17):
        observed = np.asarray(probability_node(iterations), dtype=float)
        expected, theory_success = _theory(marked, iterations)
        if observed.shape != (N_STATES,):
            raise ValueError(f"Unexpected analytic probability shape {observed.shape}")
        maximum_error = max(
            maximum_error,
            float(np.max(np.abs(observed - expected))),
            float(abs(observed.sum() - 1)),
        )
        curve.append(
            dict(
                iterations=iterations,
                success_probability=float(observed[list(marked)].sum()),
                theory=float(theory_success),
            )
        )
        if iterations == optimal:
            selected, selected_expected = observed, expected
    if selected is None or selected_expected is None:
        raise RuntimeError("Chosen stopping point is outside the executed curve")
    counts = _sample_counts(sample_node, optimal, shots)
    sampled_successes = sum(counts.get(_bits(value), 0) for value in marked)
    return dict(
        marked=list(marked),
        optimal_iterations=optimal,
        parameters={"n": N_QUBITS, "N": N_STATES, "s": len(marked), "theta": theta},
        qubits=N_QUBITS,
        labels=[_bits(x) for x in range(N_STATES)],
        probabilities=selected.tolist(),
        expected_probabilities=selected_expected.tolist(),
        counts=counts,
        shots=shots,
        seed=seed,
        success_probability=float(selected[list(marked)].sum()),
        sampled_successes=sampled_successes,
        sampled_success_probability=sampled_successes / shots,
        max_error=float(maximum_error),
        validation_passed=bool(maximum_error <= TOLERANCE and sum(counts.values()) == shots),
        curve=curve,
        circuit_text=qml.draw(probability_node, max_length=110)(optimal),
    )


def _unknown_search(seed: int) -> tuple[list[dict], dict]:
    """Bounded BBHT-style trial trace, without using s to choose iterations.

    Each trial checks one uniformly chosen classical candidate, then, if needed,
    draws j uniformly from 0..ceil(T)-1 and performs an actual one-shot QNode.
    The seven-bit oracle is fixed internally. Its cardinality is not supplied to
    the selection rule. The 32-trial limit is a demo budget, not a no-solution
    proof. A run that exhausts it returns success=False.
    """
    marked = MULTIPLE_MARKED
    _, sample_node = _make_nodes(marked, seed + 2)
    rng = np.random.default_rng(seed)
    scale = 1.0
    maximum_scale = math.sqrt(N_STATES)
    growth = 1.25
    trace = []
    total_queries = 0
    found = None
    method = None
    for trial in range(1, MAX_UNKNOWN_TRIALS + 1):
        length = math.ceil(scale)
        candidate = int(rng.integers(N_STATES))
        classical_verified = candidate in marked
        record = dict(
            trial=trial,
            window_scale=float(scale),
            window_length=length,
            classical_candidate=candidate,
            classical_bits=_bits(candidate),
            classical_verified=classical_verified,
            iterations=0,
            quantum_candidate=None,
            quantum_bits=None,
            quantum_verified=False,
            quantum_counts={},
            oracle_queries=1,
        )
        if classical_verified:
            found, method = candidate, "classical_candidate_verification"
        else:
            iterations = int(rng.integers(length))
            counts = _sample_counts(sample_node, iterations, 1)
            bits = next(iter(counts))
            quantum_candidate = int(bits, 2)
            quantum_verified = quantum_candidate in marked
            record.update(
                iterations=iterations,
                quantum_candidate=quantum_candidate,
                quantum_bits=bits,
                quantum_verified=quantum_verified,
                quantum_counts=counts,
                oracle_queries=iterations + 2,
            )
            if quantum_verified:
                found, method = quantum_candidate, "quantum_sample_verification"
        total_queries += record["oracle_queries"]
        trace.append(record)
        if found is not None:
            break
        scale = min(growth * scale, maximum_scale)

    result = dict(
        success=found is not None,
        found_value=found,
        found_bits=_bits(found) if found is not None else None,
        method=method,
        trials_used=len(trace),
        max_trials=MAX_UNKNOWN_TRIALS,
        initial_window=1.0,
        growth_factor=growth,
        window_cap=maximum_scale,
        shots_per_quantum_trial=1,
        seed=seed,
        quantum_device_seed=seed + 2,
        total_oracle_queries=total_queries,
        hidden_marked=list(marked),
        stopping_rule="已验证解才输出；32次尝试用尽时报告未找到，不证明无解。",
    )
    return trace, result


def run(seed: int = 20261012, shots: int = 2048) -> list[dict]:
    """Return one JSON-safe Grover display record, including all three cases.

    ``probabilities`` and ``expected_probabilities`` have 128 entries in big-endian
    integer order. ``counts`` holds actual samples. Errors compare analytic QNode
    probabilities to independent rotation formulas; sampling frequencies are
    intentionally not required to equal those exact probabilities.
    """
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    if isinstance(shots, bool) or not isinstance(shots, int) or shots < 1:
        raise ValueError("shots must be a positive integer")
    start = time.perf_counter()
    unique = _known_case(UNIQUE_MARKED, seed, shots)
    multiple = _known_case(MULTIPLE_MARKED, seed + 1, shots)
    unknown_trace, unknown_trials = _unknown_search(seed)
    found = unknown_trials["found_value"]
    trace_valid = (
        len(unknown_trace) <= MAX_UNKNOWN_TRIALS
        and all(item["iterations"] <= math.sqrt(N_STATES) for item in unknown_trace)
        and (found is None or found in MULTIPLE_MARKED)
    )
    maximum_error = max(unique["max_error"], multiple["max_error"])
    return [
        dict(
            id="grover",
            title="Grover：找到解，也要在正确轮次停止",
            note_ref="4.1–4.7",
            source_pages=list(range(41, 51)),
            summary=(
                "7位128个候选中搜索73：8轮后解析成功概率约99.56%；"
                "四解只需4轮，沿用8轮会降至约1.45%。曲线来自真实门电路，"
                "柱图计数来自有限次测量；未知解数另显示实际逐轮验证记录。"
            ),
            parameters={
                "n": N_QUBITS,
                "N": N_STATES,
                "marked": list(UNIQUE_MARKED),
                "s": 1,
                "iterations": unique["optimal_iterations"],
                "curve_iterations": [0, 16],
                "comparison_tolerance": TOLERANCE,
            },
            qubits=N_QUBITS,
            elapsed_seconds=float(time.perf_counter() - start),
            labels=unique["labels"],
            probabilities=unique["probabilities"],
            expected_probabilities=unique["expected_probabilities"],
            counts=unique["counts"],
            shots=shots,
            seed=seed,
            max_error=float(maximum_error),
            validation_passed=bool(
                unique["validation_passed"] and multiple["validation_passed"] and trace_valid
            ),
            circuit_text=unique["circuit_text"],
            circuit_steps=[
                "七位都施加H，准备128个候选的均匀叠加。",
                "按目标比特翻X，用H—多控X—H实现目标态相位翻转，再复原。",
                "施加H—X—多控Z—X—H扩散；本电路实现−D，全局负号不影响本实验。",
                "唯一解重复8轮；四解重复4轮；另独立执行0至16轮以查看过旋转。",
                "计算精确qml.probs，并另外用qml.sample产生实际测量计数。",
                "未知解数只按增长窗口取次数，每次实际测量后验证候选，最多32次。",
            ],
            details={
                "backend": "default.qubit (CPU)",
                "bit_order": "wire 0为最高位，标签为x6…x0，索引0…127",
                "phase_convention": "实际每轮为−C；未用于受控Grover或相位估计。",
                "success_probability": unique["success_probability"],
                "sampled_successes": unique["sampled_successes"],
                "sampled_success_probability": unique["sampled_success_probability"],
                "curve": unique["curve"],
                "multiple_case": multiple,
                "unknown_trace": unknown_trace,
                "unknown_trials": unknown_trials,
                "validation_scope": (
                    "误差比较实际qml.probs与独立旋转公式，并检查测量数量、未知策略预算和输出验证。"
                    "未知策略success另列，有限尝试失败不会被改写为成功。"
                ),
            },
        )
    ]
