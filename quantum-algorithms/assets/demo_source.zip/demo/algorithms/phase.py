"""Small PennyLane QFT, QPE, and order-finding demonstrations.

All registers use big-endian wire order.  F_N has the positive exponent
exp(2 pi i x y / N); phase estimation therefore applies its adjoint.
Analytic probabilities are compared with independent finite Fourier sums.
Finite-shot counts are produced by PennyLane sample/set_shots, never by a
separate NumPy sampling routine.  The order oracle is a small dense matrix,
not a scalable implementation of reversible modular arithmetic.
"""

from collections import Counter
from fractions import Fraction
from math import gcd, lcm
from time import perf_counter

import numpy as np
import pennylane as qml


TOLERANCE = 1e-10


def _labels(wires: int) -> list[str]:
    return [format(index, f"0{wires}b") for index in range(2**wires)]


def _basis_bits(value: int, wires: int) -> np.ndarray:
    return np.array([int(bit) for bit in format(value, f"0{wires}b")], dtype=int)


def _qft(wires: list[int]) -> None:
    """Apply positive-phase QFT, including output bit reversal.

    wires[0] is the most significant bit.  The ControlledPhaseShift matrix
    is diag(1, 1, 1, exp(i alpha)); exchanging its two wires is immaterial.
    """
    for index, target in enumerate(wires):
        qml.Hadamard(wires=target)
        for other_index in range(index + 1, len(wires)):
            angle = 2 * np.pi / 2 ** (other_index - index + 1)
            qml.ControlledPhaseShift(angle, wires=[wires[other_index], target])
    for index in range(len(wires) // 2):
        qml.SWAP(wires=[wires[index], wires[-index - 1]])


def _fourier_probabilities(phase: float, estimation_bits: int) -> np.ndarray:
    """Independent QPE distribution from finite phase-wave sums.

    Returns length 2**estimation_bits, with integer y in big-endian order.
    It avoids division by sin(pi*delta), so exact phases have no 0/0 case.
    """
    size = 2**estimation_bits
    x = np.arange(size, dtype=float)
    y = np.arange(size, dtype=float)
    amplitudes = np.exp(2j * np.pi * x[:, None] * (phase - y[None, :] / size)).mean(axis=0)
    return np.abs(amplitudes) ** 2


def _sample_counts(sample_qnode, shots: int, wire_count: int) -> dict[str, int]:
    sample = np.asarray(qml.set_shots(sample_qnode, shots=shots)(), dtype=int)
    sample = sample.reshape(shots, wire_count)
    observed = Counter("".join(str(int(bit)) for bit in row) for row in sample)
    return {label: int(observed.get(label, 0)) for label in _labels(wire_count)}


def _complex_data(state: np.ndarray, labels: list[str]) -> list[dict]:
    return [
        {
            "label": label,
            "real": float(np.real(amplitude)),
            "imag": float(np.imag(amplitude)),
            "phase_radians": float(np.angle(amplitude)),
        }
        for label, amplitude in zip(labels, state)
    ]


def _draw(circuit, wire_count: int) -> str:
    return qml.draw(circuit, decimals=3, wire_order=list(range(wire_count)), show_matrices=False)()


def _qft_demo(seed: int, shots: int) -> dict:
    started = perf_counter()
    wires = [0, 1, 2]
    x = 5
    device = qml.device("default.qubit", wires=3, seed=seed)

    def prepare():
        qml.BasisState(_basis_bits(x, 3), wires=wires)
        _qft(wires)

    @qml.qnode(device)
    def state_circuit():
        prepare()
        return qml.state()

    @qml.qnode(device)
    def sample_circuit():
        prepare()
        return qml.sample(wires=wires)

    @qml.qnode(device)
    def roundtrip_circuit():
        prepare()
        qml.adjoint(_qft)(wires)
        return qml.state()

    state = np.asarray(state_circuit(), dtype=complex)
    probabilities = np.abs(state) ** 2
    expected_state = np.exp(2j * np.pi * x * np.arange(8) / 8) / np.sqrt(8)
    expected_probabilities = np.full(8, 1 / 8, dtype=float)
    roundtrip = np.asarray(roundtrip_circuit(), dtype=complex)
    expected_input = np.eye(1, 8, x, dtype=complex).ravel()
    amplitude_error = float(np.max(np.abs(state - expected_state)))
    probability_error = float(np.max(np.abs(probabilities - expected_probabilities)))
    roundtrip_error = float(np.max(np.abs(roundtrip - expected_input)))
    max_error = max(amplitude_error, probability_error, roundtrip_error)
    counts = _sample_counts(sample_circuit, shots, 3)
    labels = _labels(3)
    return {
        "id": "qft",
        "title": "量子傅里叶变换：均匀概率中的相位结构",
        "note_ref": "3.4",
        "source_pages": [32, 33, 34, 35],
        "summary": "对 |101⟩（x=5）执行正相位 F₈。八种测量结果等概率，但复振幅含 e^{2πi·5y/8} 的相位；逆变换恢复原输入。",
        "parameters": {"input_integer": x, "input_bits": "101", "estimation_bits": 3, "fourier_sign": "+", "inverse_roundtrip": True},
        "qubits": 3,
        "elapsed_seconds": float(perf_counter() - started),
        "labels": labels,
        "probabilities": probabilities.tolist(),
        "expected_probabilities": expected_probabilities.tolist(),
        "counts": counts,
        "shots": shots,
        "seed": seed,
        "max_error": max_error,
        "validation_passed": bool(max_error < TOLERANCE and sum(counts.values()) == shots),
        "circuit_text": _draw(state_circuit, 3),
        "circuit_steps": ["制备最高位在上的 |101⟩", "逐线执行 H 与正角受控相位门", "交换第1、3线，得到标准位序的 F₈", "另执行 F₈†，检验输入恢复"],
        "details": {
            "amplitudes": _complex_data(state, labels),
            "expected_amplitudes": _complex_data(expected_state, labels),
            "qft_input": "101",
            "out_error": roundtrip_error,
            "roundtrip_amplitudes": _complex_data(roundtrip, labels),
            "amplitude_error": amplitude_error,
            "probability_error": probability_error,
            "roundtrip_error": roundtrip_error,
            "validation_tolerance": TOLERANCE,
            "display_explanation": "概率柱状图为均匀分布，并不表示QFT没有作用；请同时展示实部、虚部或相位。这里的复振幅来自PennyLane状态向量，counts来自真实的模拟器有限次测量。",
            "device": "default.qubit CPU state-vector simulator",
        },
    }


def _phase_estimation_case(phase: float, m: int, seed: int, shots: int) -> dict:
    started = perf_counter()
    controls = list(range(m))
    target = m
    device = qml.device("default.qubit", wires=m + 1, seed=seed)

    def prepare():
        qml.PauliX(wires=target)
        for wire in controls:
            qml.Hadamard(wires=wire)
        for index, wire in enumerate(controls):
            power = 2 ** (m - index - 1)
            qml.ControlledPhaseShift(2 * np.pi * phase * power, wires=[wire, target])
        qml.adjoint(_qft)(controls)

    @qml.qnode(device)
    def probabilities_circuit():
        prepare()
        return qml.probs(wires=controls)

    @qml.qnode(device)
    def sample_circuit():
        prepare()
        return qml.sample(wires=controls)

    probabilities = np.asarray(probabilities_circuit(), dtype=float)
    expected = _fourier_probabilities(phase, m)
    max_error = float(np.max(np.abs(probabilities - expected)))
    counts = _sample_counts(sample_circuit, shots, m)
    nearest_y = int(np.floor(2**m * phase + 0.5)) % 2**m
    estimate = nearest_y / 2**m
    phase_distance = min(abs(phase - estimate), 1 - abs(phase - estimate))
    exact = bool(abs(2**m * phase - round(2**m * phase)) < TOLERANCE)
    return {
        "phase": float(phase),
        "phase_fraction": str(Fraction(phase).limit_denominator(1000)),
        "estimation_bits": m,
        "qubits": m + 1,
        "elapsed_seconds": float(perf_counter() - started),
        "exact_grid_phase": exact,
        "labels": _labels(m),
        "probabilities": probabilities.tolist(),
        "expected_probabilities": expected.tolist(),
        "counts": counts,
        "shots": shots,
        "seed": seed,
        "max_error": max_error,
        "validation_passed": bool(max_error < TOLERANCE and abs(probabilities.sum() - 1) < TOLERANCE and sum(counts.values()) == shots),
        "nearest_integer": nearest_y,
        "nearest_bits": format(nearest_y, f"0{m}b"),
        "nearest_phase_estimate": float(estimate),
        "circular_phase_error": float(phase_distance),
        "nearest_probability": float(probabilities[nearest_y]),
        "nearest_probability_lower_bound": float(4 / np.pi**2),
        "circuit_text": _draw(probabilities_circuit, m + 1),
    }


def _qpe_demo(seed: int, shots: int) -> dict:
    started = perf_counter()
    exact = _phase_estimation_case(5 / 16, 4, seed + 101, shots)
    approximate = _phase_estimation_case(1 / 3, 6, seed + 102, shots)
    return {
        "id": "qpe",
        "title": "相位估计：精确二进制相位与非整格相位",
        "note_ref": "3.5",
        "source_pages": [36, 37],
        "summary": "相位5/16用4个辅助比特必得0101；相位1/3用6个辅助比特形成尖峰分布，最接近的结果是010101（21/64），并非每次测量都输出该值。",
        "parameters": {"primary_phase": "1/3", "primary_estimation_bits": 6, "exact_case_phase": "5/16", "exact_case_estimation_bits": 4, "system_eigenstate": "1", "fourier_sign": "+", "decoder": "inverse QFT"},
        "qubits": 7,
        "elapsed_seconds": float(perf_counter() - started),
        "labels": approximate["labels"],
        "probabilities": approximate["probabilities"],
        "expected_probabilities": approximate["expected_probabilities"],
        "counts": approximate["counts"],
        "shots": shots,
        "seed": seed,
        "max_error": max(exact["max_error"], approximate["max_error"]),
        "validation_passed": bool(exact["validation_passed"] and approximate["validation_passed"]),
        "circuit_text": approximate["circuit_text"],
        "circuit_steps": ["系统制备 U=PhaseShift(2πθ) 的本征态 |1⟩", "辅助比特施加 H，产生均匀叠加", "最高位控制最大幂，将相位回踢到辅助寄存器", "施加负角、逆门序的 F†", "计算解析分布并由PennyLane实际采样"],
        "details": {
            "cases": [exact, approximate],
            "primary_case": "1/3 with six estimation bits",
            "counts_seed": seed + 102,
            "phase_wave_formula": "p(y)=|2^(-m) sum_x exp(2πi x(θ-y/2^m))|²",
            "validation_tolerance": TOLERANCE,
            "device": "default.qubit CPU state-vector simulator",
            "powered_U_model": "此例U是已知单比特相位门，直接把门角乘2^k。一般未知U黑箱不能假定免费实现所有幂。",
        },
    }


def _modular_multiplication(multiplier: int, modulus: int, system_bits: int) -> np.ndarray:
    """Dense unitary extension of x -> multiplier*x mod modulus.

    Valid x occupy [0, modulus); x >= modulus are fixed.  Requires a unit
    multiplier modulo modulus.  Columns are input labels, rows outputs.
    """
    if gcd(multiplier, modulus) != 1:
        raise ValueError("Modular multiplication must use an invertible multiplier.")
    size = 2**system_bits
    if not 1 < modulus <= size:
        raise ValueError("The system register must contain all modular labels.")
    matrix = np.zeros((size, size), dtype=complex)
    for x in range(size):
        y = multiplier * x % modulus if x < modulus else x
        matrix[y, x] = 1
    return matrix


def _continued_fraction(numerator: int, denominator: int) -> tuple[list[int], list[tuple[int, int]]]:
    terms = []
    convergents = []
    p_old, p_previous, q_old, q_previous = 0, 1, 1, 0
    while denominator:
        term, remainder = divmod(numerator, denominator)
        terms.append(int(term))
        p = term * p_previous + p_old
        q = term * q_previous + q_old
        convergents.append((int(p), int(q)))
        p_old, p_previous = p_previous, p
        q_old, q_previous = q_previous, q
        numerator, denominator = denominator, remainder
    return terms, convergents


def _classical_small_order(a: int, modulus: int) -> tuple[int, list[int]]:
    """Small-instance validation oracle, not part of quantum inference."""
    orbit = []
    value = 1
    for order in range(1, modulus + 1):
        orbit.append(value)
        value = value * a % modulus
        if value == 1:
            return order, orbit
    raise ArithmeticError("No order found for an allegedly invertible multiplier.")


def _order_demo(seed: int, shots: int) -> dict:
    started = perf_counter()
    modulus, a, m, system_bits = 15, 2, 8, 4
    controls = list(range(m))
    system = list(range(m, m + system_bits))
    size = 2**m
    reference_order, orbit = _classical_small_order(a, modulus)
    powers = [2 ** (m - index - 1) for index in range(m)]
    multipliers = [pow(a, power, modulus) for power in powers]
    matrices = [_modular_multiplication(b, modulus, system_bits) for b in multipliers]
    matrix_error = max(float(np.max(np.abs(matrix.conj().T @ matrix - np.eye(16)))) for matrix in matrices)
    device = qml.device("default.qubit", wires=m + system_bits, seed=seed + 200)

    def prepare():
        qml.BasisState(_basis_bits(1, system_bits), wires=system)
        for wire in controls:
            qml.Hadamard(wires=wire)
        for wire, matrix in zip(controls, matrices):
            qml.ControlledQubitUnitary(matrix, wires=[wire] + system)
        qml.adjoint(_qft)(controls)

    @qml.qnode(device)
    def probabilities_circuit():
        prepare()
        return qml.probs(wires=controls)

    @qml.qnode(device)
    def sample_circuit():
        prepare()
        return qml.sample(wires=controls)

    probabilities = np.asarray(probabilities_circuit(), dtype=float)
    expected = sum(_fourier_probabilities(j / reference_order, m) for j in range(reference_order)) / reference_order
    max_error = max(matrix_error, float(np.max(np.abs(probabilities - expected))))
    counts = _sample_counts(sample_circuit, shots, m)
    recovery = []
    recovered_denominators = []
    verified_orders = []
    for bits, count in counts.items():
        if count == 0:
            continue
        y = int(bits, 2)
        terms, convergents = _continued_fraction(y, size)
        candidates = []
        for p, q in convergents:
            if 1 < q < modulus:
                residue = pow(a, q, modulus)
                verified = residue == 1
                candidates.append({"p": p, "q": q, "a_power_mod_N": residue, "passes_mod_power": verified})
                if verified:
                    verified_orders.append(q)
        phase_fraction = Fraction(y, size)
        if y != 0:
            recovered_denominators.append(phase_fraction.denominator)
        recovery.append({"bits": bits, "y": y, "count": count, "estimate": float(y / size), "reduced_fraction": str(phase_fraction), "continued_fraction": terms, "candidates": candidates, "informative": y != 0})
    lcm_candidate = lcm(*recovered_denominators) if recovered_denominators else None
    lcm_verified = bool(lcm_candidate is not None and pow(a, lcm_candidate, modulus) == 1)
    inferred_order = min(verified_orders) if verified_orders else lcm_candidate if lcm_verified else None
    order_matches = inferred_order == reference_order
    recovery_summary = f"本次连分数与模幂验证得到阶候选r={inferred_order}。" if inferred_order is not None else "本次有限样本尚未确认阶，需要重复采样。"
    return {
        "id": "order",
        "title": "模乘求阶：从随机 j/r 恢复周期",
        "note_ref": "3.6",
        "source_pages": [38, 39, 40],
        "summary": "N=15、a=2，系统直接制备 |0001⟩。8位QPE在0、64、128、192出现等概率峰，分别对应j/4；" + recovery_summary + "此例展示求阶核心，并非完整可扩展Shor实现。",
        "parameters": {"N": modulus, "a": a, "estimation_bits": m, "system_bits": system_bits, "system_initial_state": "0001", "oracle_dimension": 16, "expected_order": reference_order},
        "qubits": m + system_bits,
        "elapsed_seconds": float(perf_counter() - started),
        "labels": _labels(m),
        "probabilities": probabilities.tolist(),
        "expected_probabilities": expected.tolist(),
        "counts": counts,
        "shots": shots,
        "seed": seed,
        "max_error": max_error,
        "validation_passed": bool(max_error < TOLERANCE and abs(probabilities.sum() - 1) < TOLERANCE and sum(counts.values()) == shots and order_matches),
        "circuit_text": _draw(probabilities_circuit, m + system_bits),
        "circuit_steps": ["系统4位制备 |0001⟩，无需已知本征态", "8位辅助寄存器均匀叠加", "受控模乘 M_{a^(2^k) mod 15}，标签15固定", "逆QFT后测量辅助寄存器", "对实际测得y/256展开连分数并验证2^q mod 15", "可合并候选分母，确认r=4"],
        "details": {
            "sample_seed": seed + 200,
            "orbit": orbit,
            "classical_reference_order": reference_order,
            "inferred_order": inferred_order,
            "hidden_eigenphase_mixture": [{"j": j, "phase": float(j / reference_order), "weight": float(1 / reference_order)} for j in range(reference_order)],
            "peak_labels": [format(j * size // reference_order, f"0{m}b") for j in range(reference_order)],
            "controlled_powers_top_to_bottom": powers,
            "modular_multipliers_top_to_bottom": multipliers,
            "unused_basis_states_fixed": [15],
            "matrix_unitarity_error": matrix_error,
            "continued_fraction_observations": recovery,
            "lcm_candidate": lcm_candidate,
            "lcm_mod_power_verified": lcm_verified,
            "verified_order_candidates": sorted(set(verified_orders)),
            "minimality_check": [{"proper_divisor": divisor, "a_power_mod_N": pow(a, divisor, modulus)} for divisor in range(1, reference_order) if reference_order % divisor == 0],
            "validation_tolerance": TOLERANCE,
            "state_vector_dimension": 2 ** (m + system_bits),
            "state_vector_complex128_bytes": 16 * 2 ** (m + system_bits),
            "oracle_complex128_bytes_each": 16 * 16 * 16,
            "device": "default.qubit CPU state-vector simulator",
            "limitations": "16×16矩阵直接编码小规模模乘，并固定x≥15。真实可扩展实现必须分解为可逆加法/模乘、提供并清理工作比特；模拟状态内存随总比特数按2^q增长，稠密系统oracle按4^n增长。",
            "postprocessing_scope": "本例r=4整除256，峰为精确有理数；一般阶不整除2^m时还需精度界、近似连分数、随机分子约分及多次重试。y=0不提供阶信息，j=2仅给分母2。",
        },
    }


def run(seed: int = 20261012, shots: int = 2048) -> list[dict]:
    """Execute three JSON-serializable demonstration records.

    Each primary case takes `shots` real PennyLane simulator samples. QPE
    additionally executes its exact case with the same shot count. Seeds
    are recorded with deterministic offsets to distinguish sample streams.
    """
    if not isinstance(seed, int) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed must be a nonnegative integer")
    if not isinstance(shots, int) or isinstance(shots, bool) or shots < 1:
        raise ValueError("shots must be a positive integer")
    return [_qft_demo(seed, shots), _qpe_demo(seed, shots), _order_demo(seed, shots)]
