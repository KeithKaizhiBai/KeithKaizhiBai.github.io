"""Short CPU state-vector trials; no gradients, no remote quantum devices."""
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ.setdefault(name,'4')
import time
import json
from pathlib import Path
import pennylane as qml
import numpy as np
import psutil

def run():
    rows=[]
    for n in [8,12,16,20]:
        dev=qml.device('default.qubit',wires=n,seed=20261012)
        @qml.qnode(dev,interface=None)
        def circuit():
            for layer in range(3):
                for w in range(n):
                    qml.Hadamard(wires=w)
                    qml.RY(0.13*(w+1)/(layer+1),wires=w)
                for w in range(n-1):qml.CNOT(wires=[w,w+1])
            return qml.state()
        start=time.perf_counter(); state=circuit(); elapsed=time.perf_counter()-start
        error=abs(float(np.vdot(state,state).real)-1)
        if error>1e-10:raise AssertionError(f'normalization failed at {n} wires')
        rows.append({'qubits':n,'layers':3,'elapsed_seconds':elapsed,
                     'state_vector_bytes':int(state.nbytes),
                     'process_rss_after_bytes':psutil.Process().memory_info().rss,
                     'normalization_error':error})
        print(f'CPU benchmark: {n} wires, {elapsed:.3f}s',flush=True)
        del state
        if elapsed>8:
            break
    return {'backend':'default.qubit (CPU)','trials':rows,
            'blas_thread_limit':4,'seed':20261012,
            'scope':'One forward execution per point; import time excluded. RSS is an after-run reading, not a peak-memory measurement.',
            'decision':'Demo circuits at most 12 qubits; benchmarks do not establish the maximum feasible size or GPU performance.'}

if __name__=='__main__':
    result=run(); path=Path(__file__).resolve().parent/'benchmark.json'
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
