# Quantum algorithms: numerical experiments

The experiments accompany the four-chapter lecture notes. All outputs are ideal classical state-vector simulations with PennyLane default.qubit on the CPU. Counts come from actual qml.sample calls, separate from exact simulator probabilities and independent analytical references.

## Website and notes

Open site/dist/index.html directly for offline use. Alternatively, from the project root:

```powershell
demo/.venv/Scripts/python.exe -m http.server 8765 --bind 127.0.0.1 --directory demo/site/dist
```

Visit http://127.0.0.1:8765/ . The private companion is https://quantum-algorithms-qc-note-oct13.woodsyloach.chatgpt.site ; sign in with the owning ChatGPT account. Controls browse retained results. The website has no quantum execution backend.

The English v0.2 PDF revises the validated v0.1 mathematics. Frozen batch local-demo-002 records the original v0.1 PDF hash; the website manifest records the displayed note separately. Packaging does not rewrite run provenance or claim a new experiment.

## Environment and reproduction

Python 3.12 and the exact dependencies in requirements.txt were used. Create an environment from the project root (installation needs network access):

```powershell
python -m venv demo/.venv
demo/.venv/Scripts/python.exe -m pip install -r demo/requirements.txt
```

Execute a new batch and package the website:

```powershell
demo/.venv/Scripts/python.exe demo/run_demo.py --run-id local-demo-003 --shots 2048 --seed 20261012
demo/.venv/Scripts/python.exe demo/build_site.py --run-id local-demo-003 --note-version 0.2
```

The runner refuses to overwrite batches and limits shots to 128–8192. It retains four complete calculation-source snapshots, hashes, parameters, counts, environment, and the original note manifest. Identical seeds do not establish determinism across versions or machines. Source downloads include the original manifest required by the tested runner. Calculation code is unchanged during this revision.

## Implementations and conventions

| File and algorithm | Executed example | Lecture chapter |
|---|---|---|
| algorithms/query.py: Deutsch | 2 wires, all four Boolean functions | 1 |
| Deutsch–Jozsa | 4 input + 1 target; constant and balanced | 1 |
| Bernstein–Vazirani | 6 input + 1 target; coefficient 101101 | 1 |
| Simon | 4 input + 4 output; sampled GF(2) constraints, period 1011 and injective control | 1 |
| algorithms/phase.py: QFT | 3 wires; positive exponent and inverse round trip | 3 |
| QPE | Phase 5/16 with 4 estimation bits; phase 1/3 with 6 bits | 3 |
| Order finding | N=15, a=2; 8 estimation + 4 system wires | 3 |
| algorithms/search.py: Grover | N=128; one/four marked states, 0–16 iterations, unknown-count trials | 4 |

Wire 0 is the most significant bit; labels are big-endian. QFT has a positive exponent and final bit reversal. QPE uses its adjoint. The bit oracle preserves its input and XORs the function value into a target.

Probability error is the maximum absolute component difference between exact simulator and independent reference probability vectors. QFT also compares complex amplitudes componentwise and checks the inverse round trip. Order finding checks modular permutation matrices and postprocessing. Sample frequencies have statistical uncertainty; floating-point tolerances apply to exact calculations.

## Retained outputs and limits

The displayed batch is results/local-demo-002/: JSON, full CSV, tested snapshots, and exportable plots. Batch 001 remains historical evidence. Main cases use 2048 shots; the largest circuit has 12 qubits. Hardware and four CPU benchmark points remain in hardware.json and benchmark.json. RSS is a reading after execution, not peak memory. GPU detection is not a GPU benchmark; simulations use the CPU.

Order finding uses 16×16 dense modular-multiplication matrices for teaching; scalable Shor arithmetic is not implemented. The Grover decomposition has a global sign per iteration that must be accounted for in controlled use. Finite unsuccessful retries do not prove absence of solutions. Reproduction depends on source and dependency conventions, in addition to the seed.

## Hosted version maintenance

site/.openai/hosting.json retains the existing Sites ID; reuse it for updates. site/ has its own Git repository; the project root does not. Deployment metadata is in ../review/site_publication.json and later revision records.

Validate the site and data before source saving/pushing and private deployment. On Windows without Bash, ../tools/package_site_windows.py --prepare-helper <absolute-path-to-Sites-prepare-site-build.cjs> uses the unchanged official Node validator and Python tarfile for clean, already-pushed static source. It retains the archive and hash and stores no credentials. Packaging alone does not deploy.

PennyLane references: [default.qubit](https://docs.pennylane.ai/en/stable/code/api/pennylane.devices.default_qubit.DefaultQubit.html), [ControlledQubitUnitary](https://docs.pennylane.ai/en/stable/code/api/pennylane.ControlledQubitUnitary.html), [QFT](https://docs.pennylane.ai/en/stable/code/api/pennylane.QFT.html). Exact versions are locked in requirements.txt.
